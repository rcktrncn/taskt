"only_a_10mb.txt" is made it on this site. Thank you.
URL: https://onlinefiletools.com/generate-random-text-file